# ExamSeatingArrangement
The purpose of the exam seating arrangement is to generate a seating arrangement for a set of students writing an exam given the timetable of the exam, list of students writing the exam and the subjects each student is writing an exam in. The mentioned details are stored in a database. We also consider the backlogs of students if any and allot seats accordingly. <br>

This project is done using Java. The backend is given more importance in view of delivering an effective project. The server used is SQLYog and hibernate is used to create and store all the details in the tables. Servlets and jsp are used to create a very basic front end. 
<br>
